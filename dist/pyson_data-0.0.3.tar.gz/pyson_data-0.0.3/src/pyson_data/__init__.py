from .pyson import getData, getWhole, write, updateData, checkCompatible


def hello():
    print("Hello world!")